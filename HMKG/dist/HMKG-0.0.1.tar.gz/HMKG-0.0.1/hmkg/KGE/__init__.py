from .construct_triples import KGEmbedding
from .split_data import split_data